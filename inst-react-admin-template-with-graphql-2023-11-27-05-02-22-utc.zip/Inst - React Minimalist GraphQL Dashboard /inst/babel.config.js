module.exports = {
  babelrcRoots: ['.', 'api', 'frontend'],
};
