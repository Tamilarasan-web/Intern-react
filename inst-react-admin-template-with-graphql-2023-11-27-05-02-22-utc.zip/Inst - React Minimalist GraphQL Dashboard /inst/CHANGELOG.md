v3.0.0

- Bump all packages.
- Replace `next.config.js env` by `.env.local`.
- Update apollo config to support client side fetching.
- Replace render blocking css.
- fix design issues.
- Integrate baseUI grid system.
- Improve lighthouse score.

v2.0.0

- Next.js updated to v9.3.6 https://nextjs.org/blog/next-9-3
- BaseUI version updated
- New Chat UI included
- Chat Bot feature added
- library version updated
- Design issues fixed
- Faster Performance than before
- Mobile performance improved
- Responsive design issues fixed
